#include <iostream>
#include <fstream>

using namespace std;

int main()
{
	int l = 0;
	string s;

	cout << "Enter a word:";
	cin >> s;

	int h = s.length() - 1;

	while (h > 1) {
		if (s[l++] != s[h--]) {
			cout << "Not a palindrome" << endl;
			cout << "Writing a txt file. Pls wait" << endl;

			ofstream outfile("palindrome_word_checker.txt");
			outfile << "Word " << s << " not a palindrome" << endl;
			outfile.close();
		}
		if (s[l++] == s[h--]) {
			cout << "Palindrome" << endl;
			cout << "Writing a txt file. Pls wait" << endl;

			ofstream outfile("palindrome_word_checker.txt");
			outfile << "Word " << s << " a palindrome" << endl;
			outfile.close();
		}
	}

	return 0;
}