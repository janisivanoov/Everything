#include <iostream>
#include <string>
#include <functional>
#include <utility>
#include <fstream>

using namespace std;

int main()
{
	string s1, s2, s3;

	cout << "Enter first city:" << endl;
	cin >> s1;
	cout << "Enter second city:" << endl;
	cin >> s2;
	cout << "Enter third city:" << endl;
	cin >> s3;

	auto r1 = ref(s1), r2 = ref(s2), r3 = ref(s3);

	if (r2.get() < r1.get()) swap(r1, r2);
	if (r3.get() < r2.get()) swap(r2, r3);
	if (r2.get() < r1.get()) swap(r1, r2);

	ofstream outfile("cities.txt");
	outfile << r1.get() << r2.get() << r3.get() << endl;
	outfile.close();

	return 0;
}