#include <iostream>
#include <conio.h>
using namespace std;

int main()
{
	int i, j, k, rows;
	cout << "Enter the number of rows: ";
	cin >> rows;
	for (i = rows; i >= 1; i--) {
		for (j = rows; j >= 1 + rows - i; j--) {
			cout << "*";
		}
		for (j = i * 2; j < rows * 2 - 1; j++) {
			cout << " ";
		}

		for (k = 1 + rows - i; k <= rows; k++) {
			if (k != 1)
				cout << "*";
		}

		cout << "\n";
	}
	return 0;
}