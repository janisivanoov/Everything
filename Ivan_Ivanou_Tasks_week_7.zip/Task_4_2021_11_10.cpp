#include <iostream>

using namespace std;

int main()
{
	int num1, num2 = 1, num3;
	char n, y = NULL;
	cout << "Start? y/n" << endl;
	cin >> y;
	while (y == 'y') {
		cout << "Enter number: ";
		cin >> num3;

		cout << "Enter how much times u want to repeat it: ";
		cin >> num1;
		if (num3 > 0.0) {
			for (int i = 0; i < num1; i++) {
				cout << "****\n" << "*" << num3++ << "*\n" << "****" << endl;
			}
		}
		if (num3 < 0.0) {
			cout << "Negative" << endl;
		}
		cout << "\nAgain \ny/n" << endl;;
		cin >> y;
	}
}