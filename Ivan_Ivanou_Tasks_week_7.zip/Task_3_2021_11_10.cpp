#include <iostream>

using namespace std;

int main()
{
	int all = 1000, age = 12, given, gift = 10, sum = 0;

	cout << "Birthday\t" << "Amount Given\n";
	cout << "---------\t" << "----------\n";

	while (gift < all) {
		age++;
		gift = gift + 10;
		cout << age << "\t\t" << gift << "\n";
	}

	return 0;
}